// Formatter class — plain class, no generics or decorators

export class Formatter {
    private locale: string;

    constructor(locale: string) {
        this.locale = locale;
    }

    formatNumber(n: number): string {
        return n.toLocaleString(this.locale);
    }

    formatDate(d: Date): string {
        return d.toLocaleDateString(this.locale);
    }
}
