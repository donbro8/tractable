// String helper functions — plain functions only

export function reverse(s: string): string {
    return s.split("").reverse().join("");
}

export function capitalize(s: string): string {
    if (s.length === 0) return s;
    return s.charAt(0).toUpperCase() + s.slice(1).toLowerCase();
}

export function countVowels(s: string): number {
    return (s.match(/[aeiouAEIOU]/g) || []).length;
}
