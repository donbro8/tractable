# fixture-typescript-frontend

A minimal TypeScript project used as a Tractable integration test fixture.

## Parser Constraint (Phase 4 Deferred)

This fixture is deliberately constrained to **plain functions and classes only**.
The following TypeScript constructs are intentionally absent:

- Interfaces (deferred to Phase 4)
- Type aliases (deferred to Phase 4)
- Generic type parameters (deferred to Phase 4)
- Enum types (deferred to Phase 4)
- Decorators (deferred to Phase 4)
- `.d.ts` declaration files (deferred to Phase 4)

EC5 validates that registration completes without error and the graph contains
a non-zero entity count. It does NOT assert graph completeness for TypeScript.
