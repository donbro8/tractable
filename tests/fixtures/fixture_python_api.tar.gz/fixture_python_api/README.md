# fixture-python-api

A minimal Python project used as a Tractable integration test fixture.

## Known Bug
src/calculator.py: `divide(a, 0)` raises ZeroDivisionError instead of returning infinity or raising ValueError.
