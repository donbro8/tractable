"""String helper utilities."""


def reverse(s: str) -> str:
    return s[::-1]


def is_palindrome(s: str) -> bool:
    cleaned = s.lower().replace(" ", "")
    return cleaned == cleaned[::-1]


def count_vowels(s: str) -> int:
    return sum(1 for c in s.lower() if c in "aeiou")
