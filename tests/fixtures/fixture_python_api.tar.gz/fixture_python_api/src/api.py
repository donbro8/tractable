"""Minimal FastAPI application."""

from fastapi import FastAPI, HTTPException
from .calculator import add, divide
from .string_utils import reverse

app = FastAPI()


@app.get("/add")
def route_add(a: int, b: int) -> dict:
    return {"result": add(a, b)}


@app.get("/divide")
def route_divide(a: int, b: int) -> dict:
    if b == 0:
        raise HTTPException(status_code=400, detail="Cannot divide by zero")
    return {"result": divide(a, b)}


@app.get("/reverse")
def route_reverse(s: str) -> dict:
    return {"result": reverse(s)}
