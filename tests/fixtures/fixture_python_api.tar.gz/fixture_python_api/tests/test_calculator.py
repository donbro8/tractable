"""Tests for calculator module."""

import pytest
from src.calculator import add, subtract, multiply, divide


def test_add():
    assert add(2, 3) == 5


def test_subtract():
    assert subtract(5, 3) == 2


def test_multiply():
    assert multiply(3, 4) == 12


def test_divide_normal():
    assert divide(10, 2) == 5.0


def test_divide_by_zero_raises():
    # BUG: divide(8, 0) raises ZeroDivisionError; should raise ValueError
    with pytest.raises(ZeroDivisionError):
        divide(8, 0)
