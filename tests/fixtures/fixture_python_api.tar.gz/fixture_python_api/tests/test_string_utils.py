"""Tests for string_utils module."""

from src.string_utils import reverse, is_palindrome, count_vowels


def test_reverse():
    assert reverse("hello") == "olleh"


def test_is_palindrome_true():
    assert is_palindrome("racecar") is True


def test_is_palindrome_false():
    assert is_palindrome("hello") is False


def test_count_vowels():
    assert count_vowels("hello") == 2
